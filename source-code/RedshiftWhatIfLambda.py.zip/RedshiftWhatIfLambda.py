import boto3
import time
import traceback
import botocore.exceptions as be
import json
import re

def handler(event, context):
    print(event)
    action = event['Input'].get('action')
    config = get_json_config_from_s3(event['Input'].get('config_json_s3_path'))
    what_if_timestamp = event['Input'].get('what_if_timestamp')
    cluster_identifier = event['Input'].get('cluster_identifier')
    cluster_identifier_prefix = event['Input'].get('cluster_identifier_prefix')

    sql_id = event['Input'].get('sql_id')
    redshift_cluster_configuration = event['Input'].get('redshift_cluster_configuration')

    try:
        client = boto3.client('redshift')
        if action == "initiate":
            if config.get('s3_bucket_name') is None or config.get('redshift_iam_role') is None or config.get('security_group_id') is None or config.get('subnet_group') is None:
                raise ValueError('invalid version of user-config file. Please ensure to use user-config file version, post cloudFormation template deployment')
            what_if_timestamp = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
            s3_put(config.get('s3_bucket_name'), 'query_stats/' + what_if_timestamp + "/'")
            res = {'status': what_if_timestamp}
        elif action == "get_redshift_configurations":
            res = {'status': config.get('configurations')}
        elif action == "get_cluster_identifier":
            res = {'status': get_cluster_identifier(client, config, redshift_cluster_configuration, cluster_identifier_prefix)}
        elif action == "cluster_status":
            res = {'status': cluster_status(client, cluster_identifier)}
        elif action == "create_parameter_group":
            res = {'status': create_parameter_group(client, cluster_identifier)}
        elif action == "update_parameter_group":
            res = {'status': update_parameter_group(client, cluster_identifier,
                                                    config.get('parameter_group_config_s3_path'))}

        elif action == "create_cluster":
            res = {
                'status': create_cluster(client,
                                         cluster_identifier,
                                         config.get('snapshot_id'),
                                         config.get('redshift_iam_role'),
                                         cluster_identifier,
                                         config.get('subnet_group'),
                                         config.get('security_group_id'),
                                         config.get('snapshot_account_id'),
                                         redshift_cluster_configuration.get('node_type'),
                                         redshift_cluster_configuration.get('number_of_nodes'),
                                         master_user_name=config.get('master_user_name'),
                                         database_name=config.get('database_name'),
                                         secrets_manager_arn=config.get('secrets_manager_arn')
                                         )}

        elif action == "classic_resize_cluster":
            res = {'status': classic_resize_cluster(client, cluster_identifier,
                                                    redshift_cluster_configuration.get('node_type'),
                                                    redshift_cluster_configuration.get('number_of_nodes'))}
        elif action == "resume_cluster":
            client.resume_cluster(ClusterIdentifier=cluster_identifier)
            res = {'status': 'initiated'}
        elif action == "pause_cluster":
            res = {'status': pause_cluster(client, cluster_identifier,config.get('auto_pause'))}
        elif action == "update_wlm_config":
            res = {'status': update_wlm_config(client, cluster_identifier, redshift_cluster_configuration.get('wlm_config_s3_path'))}
        elif action == "run_ddl_and_copy_script":
            RESULT_CACHE = 'true'
            res = {'sql_id': run_sql_script_from_s3(config.get('ddl_and_copy_script_s3_path'), RESULT_CACHE, action,
                                                    cluster_identifier,
                                                    config.get('redshift_iam_role'), config.get('s3_bucket_name'),
                                                    config.get('database_name'), config.get('master_user_name'))}
        elif action == "test_sequential_queries_and_load":
            RESULT_CACHE = 'true'
            res = {'sql_id': run_sql_script_from_s3(config.get('sequential_queries_and_load_s3_path'), RESULT_CACHE,
                                                    action,
                                                    cluster_identifier,
                                                    config.get('redshift_iam_role'), config.get('s3_bucket_name'),
                                                    config.get('database_name'), config.get('master_user_name'))}
        elif action == "test_concurrent_user_queries_and_load":
            RESULT_CACHE = 'true'
            res = {
                'sql_id': run_sql_script_from_s3(config.get('concurrent_user_queries_and_load_s3_path'), RESULT_CACHE,
                                                 action,
                                                 cluster_identifier,
                                                 config.get('redshift_iam_role'), config.get('s3_bucket_name'),
                                                 config.get('database_name'), config.get('master_user_name'))}
        elif action == "run_sequential_queries_and_load":
            RESULT_CACHE = 'false'
            res = {'sql_id': run_sql_script_from_s3(config.get('sequential_queries_and_load_s3_path'), RESULT_CACHE,
                                                    action,
                                                    cluster_identifier,
                                                    config.get('redshift_iam_role'), config.get('s3_bucket_name'),
                                                    config.get('database_name'), config.get('master_user_name'))}
        elif action == "run_concurrent_user_queries_and_load":
            RESULT_CACHE = 'false'
            res = {'sql_id': run_concurrent_sql_scripts_from_s3(config.get('concurrent_user_queries_and_load_s3_path'),
                                                                RESULT_CACHE,
                                                                action,
                                                                cluster_identifier,
                                                                config.get('redshift_iam_role'),
                                                                config.get('s3_bucket_name'),
                                                                config.get('database_name'),
                                                                config.get('master_user_name'))}
        elif action == "unload_stats":
            res = {'sql_id': unload_stats(
                action,
                cluster_identifier,
                config.get('redshift_iam_role'),
                config.get('s3_bucket_name'),
                config.get('database_name'),
                config.get('master_user_name'),
                what_if_timestamp)}
        elif action == "sql_status":
            res = {'status': sql_status(sql_id)}

        elif action == "concurrent_sql_status":
            res = {'status': concurrent_sql_status(sql_id)}

        else:
            raise ValueError("Invalid Task: " + action)
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        raise
    print(res)
    return res


def pause_cluster(client, cluster_identifier, auto_pause):
    if auto_pause:
        try:
            client.pause_cluster(ClusterIdentifier=cluster_identifier)
        except be.ClientError as e:
            if e.response['Error']['Code'] == 'InvalidClusterState':
                print(e.response['Error']['Code'])
            else:
                raise
        return "initiated"
    else:
        return "auto_pause config is false"


def cluster_status(client, clusterid):
    try:
        desc = client.describe_clusters(ClusterIdentifier=clusterid)['Clusters'][0]
        if isinstance(desc, dict):
            status = desc.get('ClusterStatus') + desc.get('ClusterAvailabilityStatus') + (
                desc.get('RestoreStatus').get('Status') if desc.get('RestoreStatus') else "")
        else:
            status = 'Unavailable'
    except be.ClientError as e:
        msg = e.response['Error']['Code']
        if msg == 'ClusterNotFound':
            status = 'nonExistent'
        else:
            print(desc)
            raise
    return status

def get_cluster_identifier(client, config, redshift_configurations, cluster_identifier_prefix):
    if redshift_configurations.get('user_friendly_name_suffix') is None or redshift_configurations.get(
            'user_friendly_name_suffix') == 'N/A':
        if redshift_configurations.get('wlm_config_s3_path') is None or redshift_configurations.get('wlm_config_s3_path') == 'N/A':
            wlm_name = ""
        else:
            wlm_name = redshift_configurations.get('wlm_config_s3_path').replace("s3://", "").replace("/", "").replace(".json", "")
            wlm_name = re.sub('[^A-Za-z0-9]+', '', wlm_name)
        cluster_suffix = redshift_configurations.get('node_type') + "-" + redshift_configurations.get(
            'number_of_nodes') + wlm_name
        cluster_suffix = cluster_suffix.replace(".", "-")
    else:
        cluster_suffix = redshift_configurations.get('user_friendly_name_suffix')
    return (cluster_identifier_prefix + "-" + cluster_suffix)[0:63]


def update_wlm_config(client, cluster_identifier, wlm_config_s3_path):
    if wlm_config_s3_path is None or wlm_config_s3_path=="N/A":
        return "N/A"
    else:
        wlm_config = get_json_config_from_s3(wlm_config_s3_path)
        print("Changing {} parameter group wlm : {}".format(cluster_identifier, wlm_config))
        client.modify_cluster_parameter_group(
            ParameterGroupName=cluster_identifier,
            Parameters=[
                {
                    'ParameterName': 'wlm_json_configuration',
                    'ParameterValue': json.dumps(wlm_config),
                    'ApplyType': 'dynamic',
                    'IsModifiable': True
                },
            ])
    return "initiated"

def create_snapshot(client, cluster_identifier):
    try:
        client.create_cluster_snapshot(
            ClusterIdentifier=cluster_identifier,
            SnapshotIdentifier=cluster_identifier,
            ManualSnapshotRetentionPeriod=1
        )
    except be.ClientError as e:
        msg = e.response['Error']['Code']
        if msg == 'ClusterSnapshotAlreadyExists':
            print(msg)
        else:
            raise
    return 'initiated'


def snapshot_status(client, cluster_identifier):
    try:
        r = client.describe_cluster_snapshots(SnapshotIdentifier=cluster_identifier)
        status = r['Snapshots'][0]['Status']
    except be.ClientError as e:
        msg = e.response['Error']['Code']
        if msg == 'ClusterNotFound':
            status = 'nonExistent'
        else:
            raise
    return status

def delete_snapshot(client, cluster_identifier):
    try:
        r = client.delete_cluster_snapshot(SnapshotIdentifier=cluster_identifier)
        status = r['Snapshots'][0]['Status']
    except be.ClientError as e:
        msg = e.response['Error']['Code']
        if msg == 'ClusterNotFound':
            status = 'nonExistent'
        else:
            raise
    return status

def get_json_config_from_s3(script_s3_path):
    bucket, key = script_s3_path.replace("s3://", "").split("/", 1)
    obj = boto3.client('s3').get_object(Bucket=bucket, Key=key)
    return json.loads(obj['Body'].read().decode('utf-8'))


def run_sql_script_from_s3(script_s3_path, result_cache, action, cluster_identifier, redshift_iam_role, bucket_name, db,
                           user, run_type='async', with_event=False, what_if_timestamp=None):
    if script_s3_path == "N/A":
        return "N/A"
    else:
        bucket, key = script_s3_path.replace("s3://", "").split("/", 1)
        obj = boto3.client('s3').get_object(Bucket=bucket, Key=key)
        script = obj['Body'].read().decode('utf-8')
        script = script.format(redshift_iam_role=redshift_iam_role, bucket_name=bucket_name,
                               cluster_identifier=cluster_identifier, what_if_timestamp=what_if_timestamp)
        if action == 'unload_stats':
            sql_id = run_sql(cluster_identifier, db, user, script, with_event, run_type)
        else:
            query_group_statement = "set query_group to '" + action + "';\n"
            result_cache_statement = "set enable_result_cache_for_session to " + result_cache + "; \n"
            script = query_group_statement + result_cache_statement + script
            sql_id = run_sql(cluster_identifier, db, user, script, with_event, run_type)
        return sql_id

def run_concurrent_sql_scripts_from_s3(script_s3_path, result_cache, action,
                                       cluster_identifier, redshift_iam_role, bucket_name, db, user):
    sql_ids = []
    if script_s3_path == "N/A":
        sql_ids.append("N/A")
    else:
        bucket, key = script_s3_path.replace("s3://", "").split("/", 1)
        obj = boto3.client('s3').get_object(Bucket=bucket, Key=key)
        scripts = obj['Body'].read().decode('utf-8')
        scripts = scripts.format(redshift_iam_role=redshift_iam_role, bucket_name=bucket_name,cluster_identifier=cluster_identifier)
        split_scripts = scripts.split(';')[:-1]

        start = time.process_time()
        for script in split_scripts:
            query_group_statement = "set query_group to '" + action + "';\n"
            result_cache_statement = "set enable_result_cache_for_session to " + result_cache + "; \n"
            script = query_group_statement + result_cache_statement + script

            res = boto3.client("redshift-data").execute_statement(Database=db, DbUser=user, Sql=script,
                                                                  ClusterIdentifier=cluster_identifier)
            sql_id = res["Id"]
            sql_ids.append(sql_id)
        print(f'Time taken to submit concurrent scripts:{time.process_time() - start} seconds')
    return sql_ids


def unload_stats(action, cluster_identifier, redshift_iam_role, bucket_name, db, user, what_if_timestamp):
    EXTERNAL_SCHEMA_S3_PATH = 's3://event-driven-app-with-lambda-redshift/whatif/what_if_external_schema.sql'
    EXTERNAL_TABLE_S3_PATH = 's3://event-driven-app-with-lambda-redshift/whatif/what_if_external_table.sql'
    EXTERNAL_PARTITION_S3_PATH = 's3://event-driven-app-with-lambda-redshift/whatif/what_if_external_partition.sql'
    UNLOAD_STATS_S3_PATH = 's3://event-driven-app-with-lambda-redshift/whatif/unload_query_stats.sql'
    RESULT_CACHE = 'true'
    RUN_TYPE = 'sync'
    with_event = False
    try:

        run_sql_script_from_s3(EXTERNAL_SCHEMA_S3_PATH, RESULT_CACHE, action, cluster_identifier, redshift_iam_role,
                               bucket_name, db, user, RUN_TYPE, with_event, what_if_timestamp)
    except Exception as e:
        if str(e) != 'ERROR: Schema "redshift_what_if" already exists':
            raise

    try:
        run_sql_script_from_s3(EXTERNAL_TABLE_S3_PATH, RESULT_CACHE, action, cluster_identifier, redshift_iam_role,
                               bucket_name, db, user, RUN_TYPE, with_event, what_if_timestamp)
    except Exception as e:
        if str(e) != 'ERROR: Table already exists.':
            raise

    try:
        run_sql_script_from_s3(EXTERNAL_PARTITION_S3_PATH, RESULT_CACHE, action, cluster_identifier, redshift_iam_role,
                               bucket_name, db, user, RUN_TYPE, with_event, what_if_timestamp)
    except Exception as e:
        msg = 'ERROR: [' + what_if_timestamp + ',' + cluster_identifier + '] Partition already exists.'
        if str(e) != msg:
            raise
    run_sql_script_from_s3(UNLOAD_STATS_S3_PATH, RESULT_CACHE, action, cluster_identifier, redshift_iam_role,
                           bucket_name, db, user, RUN_TYPE, with_event, what_if_timestamp)
    return 'FINISHED'


def create_parameter_group(client, parameter_group_name):
    try:
        client.create_cluster_parameter_group(
            ParameterGroupName=parameter_group_name,
            ParameterGroupFamily='redshift-1.0',
            Description='redshift cluster parameter group'
        )
    except be.ClientError as e:
        if e.response['Error']['Code'] == 'ClusterParameterGroupAlreadyExists':
            print(e.response['Error']['Code'])
        else:
            raise
    return 'initiated'


def parameter_group_status(client, parameter_group_name):
    parameter_group = client.describe_cluster_parameters(ParameterGroupName=parameter_group_name)
    return parameter_group


def update_parameter_group(client, parameter_group_name, parameter_group_config_s3_path):
    target_parameter_group = client.describe_cluster_parameters(ParameterGroupName=parameter_group_name)["Parameters"]
    target_parameters = {}
    for i in target_parameter_group:
        target_parameters[i['ParameterName']] = i['ParameterValue']
    source_parameter_group = get_json_config_from_s3(parameter_group_config_s3_path)["Parameters"]
    modified_parameter_group = []
    for i in source_parameter_group:
        source_parameter_value = i['ParameterValue'].replace(" ", "")
        target_parameter_value = target_parameters[i['ParameterName']].replace(" ", "")
        if source_parameter_value != target_parameter_value:
            modified_parameter_group.append(i)
    if modified_parameter_group:
        client.modify_cluster_parameter_group(
            ParameterGroupName=parameter_group_name,
            Parameters=modified_parameter_group)
    return "Initiated"


def classic_resize_cluster(client, clusterid, node_type, number_of_nodes):
    client.resize_cluster(ClusterIdentifier=clusterid, NodeType=node_type, NumberOfNodes=int(number_of_nodes),
                          ClusterType='single-node' if int(number_of_nodes) == 1 else 'multi-node', Classic=True)
    return "Initiated"


def create_cluster(client, cluster_identifier, snapshot_id, redshift_iam_role, parameter_group_name, subnet_group,
                   security_group_id, snapshot_account_id, node_type, number_of_nodes, master_user_name, database_name, secrets_manager_arn):
    PORT = 5439
    PUBLICLY_ACCESSIBLE = False
    ENHANCED_VPC_ROUTING = False

    try:
        if snapshot_id is None or snapshot_id == "N/A":
            master_user_secret = json.loads(boto3.client('secretsmanager').get_secret_value(SecretId=secrets_manager_arn).get('SecretString'))
            master_user_password = master_user_secret.get('password')
            client.create_cluster(DBName=database_name,
                                  ClusterIdentifier=cluster_identifier,
                                  ClusterType='single-node' if int(number_of_nodes) == 1 else 'multi-node',
                                  NodeType=node_type,
                                  MasterUsername=master_user_name,
                                  MasterUserPassword=master_user_password,
                                  VpcSecurityGroupIds=[security_group_id],
                                  ClusterSubnetGroupName=subnet_group,
                                  ClusterParameterGroupName=parameter_group_name,
                                  Port=PORT,
                                  NumberOfNodes=int(number_of_nodes),
                                  PubliclyAccessible=PUBLICLY_ACCESSIBLE,
                                  IamRoles=[redshift_iam_role])
        else:
            if snapshot_account_id is None or snapshot_account_id == "N/A":
                snapshot_account_id = boto3.client('sts').get_caller_identity()['Account']

            client.restore_from_cluster_snapshot(NumberOfNodes=int(number_of_nodes),
                                                 NodeType=node_type,
                                                 ClusterIdentifier=cluster_identifier,
                                                 SnapshotIdentifier=snapshot_id,
                                                 OwnerAccount=snapshot_account_id,
                                                 Port=PORT,
                                                 ClusterSubnetGroupName=subnet_group,
                                                 PubliclyAccessible=PUBLICLY_ACCESSIBLE,
                                                 ClusterParameterGroupName=parameter_group_name,
                                                 VpcSecurityGroupIds=[security_group_id],
                                                 EnhancedVpcRouting=ENHANCED_VPC_ROUTING,
                                                 IamRoles=[redshift_iam_role])
        status = 'Initiated'
    except be.ClientError as e:
        msg = e.response['Error']['Code']
        if msg == 'ClusterAlreadyExists':
            status = msg
        elif msg == 'InvalidParameterValue':
            source_node_type, source_number_of_nodes = get_source_cluster_config(client, snapshot_id)
            client.restore_from_cluster_snapshot(NumberOfNodes=source_number_of_nodes,
                                                 NodeType=source_node_type,
                                                 ClusterIdentifier=cluster_identifier,
                                                 SnapshotIdentifier=snapshot_id,
                                                 OwnerAccount=snapshot_account_id,
                                                 Port=PORT,
                                                 ClusterSubnetGroupName=subnet_group,
                                                 PubliclyAccessible=PUBLICLY_ACCESSIBLE,
                                                 ClusterParameterGroupName=parameter_group_name,
                                                 VpcSecurityGroupIds=[security_group_id],
                                                 IamRoles=[redshift_iam_role])
            status = 'NeedClassicResize'
        else:
            raise
    return status


def get_source_cluster_config(client, snapshot_id):
    resp = client.describe_cluster_snapshots(SnapshotIdentifier=snapshot_id)
    node_type = resp['Snapshots'][0]['NodeType']
    number_of_nodes = resp['Snapshots'][0]['NumberOfNodes']
    return (node_type, number_of_nodes)


def run_sql(clusterid, db, user, script, with_event, run_type):
    res = boto3.client("redshift-data").execute_statement(Database=db, DbUser=user, Sql=script,
                                                          ClusterIdentifier=clusterid, WithEvent=with_event)
    query_id = res["Id"]
    done = False
    while not done:
        status = sql_status(query_id)
        if run_type == 'async':
            break
        elif status == "FINISHED":
            break
    return query_id


def concurrent_sql_status(query_ids):
    all_status = [sql_status(query_id) for query_id in query_ids]
    for i in all_status:
        if i != "FINISHED":
            return i
    return "FINISHED"


def sql_status(query_id):
    if query_id=="N/A":
        return "FINISHED"
    res = boto3.client("redshift-data").describe_statement(Id=query_id)
    status = res["Status"]
    if status == "FAILED":
        print(res)
        raise Exception(res["Error"])
    return status.strip('"')


def upload_params(client, endpoint, snapshotid, bucket, prefix):
    port, db = endpoint.split(':')[1].split('/')
    cluster = client.describe_clusters(ClusterIdentifier=endpoint.split('.')[0])['Clusters'][0]
    security_groups = [item['VpcSecurityGroupId'] for item in cluster.get('VpcSecurityGroups')]
    parameter_group = cluster.get('ClusterParameterGroups')[0].get('ParameterGroupName')
    parameter_group_dict = client.describe_cluster_parameters(ParameterGroupName=parameter_group)
    s3_put(parameter_group_dict, bucket, prefix + "parameter_group.json")

    config_dict = {'availability_zone': cluster.get('AvailabilityZone'),
                   'enhanced_vpc_routing': str(cluster.get('EnhancedVpcRouting')),
                   'parameter_group': parameter_group,
                   'port': port,
                   'db': db,
                   'publicly_accessible': str(cluster.get('PubliclyAccessible')),
                   'security_groups': ','.join(security_groups),
                   'snapshot_id': snapshotid,
                   'cluster_subnet_group': cluster.get('ClusterSubnetGroupName'),
                   'node_type': cluster.get('NodeType'),
                   'number_of_nodes': str(cluster.get('NumberOfNodes'))
                   }
    s3_put(config_dict, bucket, prefix + "config.json")
    return config_dict


def s3_put(bucket, key, object=None):
    s3 = boto3.client('s3')
    if object != None:
        s3.put_object(Bucket=bucket, Key=key, Body=object)
    else:
        s3.put_object(Bucket=bucket, Key=key)
